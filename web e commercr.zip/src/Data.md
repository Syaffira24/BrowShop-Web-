COLOR
#789DBC
#FFE3E3
#FEF9F2
#C9E9D2

{ id: 1, name: "T-shirt", price: 150000, description: "Cotton T-shirt with graphic design.", image: "" },
    { id: 2, name: "Jeans", price: 200000, description: "Denim jeans with a slim fit.", image: "" },
    { id: 3, name: "Jacket", price: 300000, description: "Warm winter jacket with hood.", image: "" },
    { id: 4, name: "Sneakers", price: 500000, description: "Comfortable sneakers for daily use.", image: "" },
    { id: 5, name: "Cap", price: 100000, description: "Classic baseball cap.", image: "" },
    { id: 6, name: "Belt", price: 75000, description: "Leather belt with buckle.", image: "" },
    { id: 7, name: "Sweater", price: 250000, description: "Soft knitted sweater for colder days.", image: "" },
    { id: 8, name: "Shorts", price: 120000, description: "Casual shorts for everyday wear.", image: "" },
    { id: 9, name: "Boots", price: 450000, description: "Durable leather boots for outdoor use.", image: "" },
    { id: 10, name: "Sunglasses", price: 180000, description: "Stylish sunglasses with UV protection.", image: "" },
    { id: 11, name: "Watch", price: 350000, description: "Elegant wristwatch with metal band.", image: "" },
    { id: 12, name: "Scarf", price: 90000, description: "Warm wool scarf for winter.", image: "" },
    { id: 13, name: "Hoodie", price: 220000, description: "Cozy hoodie for casual wear.", image: "" },
    { id: 14, name: "Sweatpants", price: 180000, description: "Comfortable sweatpants for lounging.", image: "" },
    { id: 15, name: "Flip Flops", price: 50000, description: "Casual flip flops for beach days.", image: "" },
    { id: 16, name: "Raincoat", price: 280000, description: "Waterproof raincoat for rainy days.", image: "" },
    { id: 17, name: "Beanie", price: 60000, description: "Warm knitted beanie for winter.", image: "" },
    { id: 18, name: "Gloves", price: 90000, description: "Leather gloves for winter.", image: "" },
    { id: 19, name: "Polo Shirt", price: 170000, description: "Classic polo shirt for smart casual look.", image: "" },
    { id: 20, name: "Boots", price: 550000, description: "Stylish leather boots for formal and casual.", image: "" },
    { id: 21, name: "Bag", price: 320000, description: "Casual crossbody bag for everyday use.", image: "" },
    { id: 22, name: "Sweater Vest", price: 230000, description: "Lightweight sweater vest for layering.", image: "" },
    { id: 23, name: "Windbreaker", price: 270000, description: "Light jacket for breezy days.", image: "" },
    { id: 24, name: "Chinos", price: 220000, description: "Comfortable chinos for casual wear.", image: "" },