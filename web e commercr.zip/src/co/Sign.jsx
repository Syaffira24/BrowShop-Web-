import { useState } from 'react';
import './css/Login.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function Sign() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(''); 
  const [loading, setLoading] = useState(false);

  const getPasswordStrength = (password) => {
    if (password.length >= 12 && /[A-Za-z]/.test(password) && /\d/.test(password) && /[!@#$%^&*]/.test(password)) {
      return 'strong'; 
    } else if (password.length >= 8 && /[A-Za-z]/.test(password) && /\d/.test(password)) {
      return 'medium';
    } else {
      return 'weak'; 
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    setSuccess('');
    setError('');

    if (!username || !email || !password || !confirmPassword) {
      setError('All fields are required!');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match!');
      return;
    }

    const passwordStrength = getPasswordStrength(password);
    if (passwordStrength === 'weak') {
      setError('Password is too weak!');
      return;
    }

    setLoading(true);
  
    setTimeout(() => {
      setLoading(false);
      setSuccess('Registration successful!'); 
      console.log("Sign Up submitted", { username, email, password });
    }, 2000); 
  };

  const passwordStrength = getPasswordStrength(password);

  return (
    <>
    <div className="sign-container">
      <h2>Sign Up</h2>


      {error && <div className="alert alert-danger">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}

      <form onSubmit={handleSubmit}>
        <div className="input-group">
          <i className="fa fa-user"></i>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>

        <div className="input-group">
          <i className="fa fa-envelope"></i>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="input-group">
          <i className="fa fa-eye" onClick={() => setShowPassword(!showPassword)} style={{ cursor: 'pointer' }}></i>
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <div className="input-group">
          <i className="fa fa-eye" onClick={() => setShowConfirmPassword(!showConfirmPassword)} style={{ cursor: 'pointer' }}></i>
          <input
            type={showConfirmPassword ? 'text' : 'password'}
            placeholder="Confirm Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
        </div>

        <div className={`password-strength-bar ${passwordStrength}`}>
          <div className="strength-indicator" />
        </div>

        <button type="submit" className="login-btn" disabled={loading}>
          {loading ? (
            <div className="loading-spinner"></div>
          ) : (
            'Register'
          )}
        </button>
      </form>
    </div>
    </>
  );
}

export default Sign;
