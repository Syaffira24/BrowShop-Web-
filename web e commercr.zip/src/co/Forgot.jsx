import { useState } from 'react';
import './css/Login.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function Forgot() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Username dan Password Tidak terdaftar');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      console.log("Login submitted", { username, password });
    }, 2000); 
  };

  return (
    <div className="login-container">
      <h2>Forget</h2>
      
      {error && <div className="alert alert-danger">{error}</div>}

      <form onSubmit={handleSubmit}>
        <div className="input-group">
          <i className="fa fa-user"></i>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>

        <div className="input-group">
          <i className="fa fa-eye" onClick={() => setShowPassword(!showPassword)} style={{ cursor: 'pointer' }}></i>
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <div className="button-action">
       <a href="/" className="forget-btn btn">Back</a>
       <button type="submit" className="login-btn" disabled={loading}>
    {loading ? <div className="loading-spinner"></div> : 'Next'}
  </button>
    </div>

      </form>
    </div>
  );
}

export default Forgot;
