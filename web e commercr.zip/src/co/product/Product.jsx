import React, { useState } from 'react';
import './style/styles.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Modal } from 'react-bootstrap';


import img from './Assets/image.png';
import img1 from './Assets/image-1.png';
import img2 from './Assets/image-2.png';
import img3 from './Assets/image-3.png';
import img4 from './Assets/image-4.png';
import img5 from './Assets/image-5.png';
import img6 from './Assets/image-6.png';
import img7 from './Assets/image-7.png';
import img8 from './Assets/image-8.png';
import img9 from './Assets/image-9.png';
import img10 from './Assets/image-10.png';
import img11 from './Assets/image-11.png';
import img12 from './Assets/image-12.png';
import img13 from './Assets/image-13.png';
import img14 from './Assets/image-14.png';
import img15 from './Assets/image-15.png';

import img16 from './Assets/image-16.jpg';
import img17 from './Assets/image-17.jpg';
import img18 from './Assets/image-18.jpg';
import img19 from './Assets/image-19.jpg';
import img20 from './Assets/image-20.jpeg';
import img21 from './Assets/image-21.jpeg';
import img22 from './Assets/image-22.jpeg';
import img23 from './Assets/image-23.jpeg';
import img24 from './Assets/image-24.jpeg';
import img25 from './Assets/image-25.jpeg';
import img26 from './Assets/image-26.jpeg';
import img27 from './Assets/image-27.jpeg';
import img28 from './Assets/image-28.jpeg';
import img29 from './Assets/image-29.jpeg';
import img30 from './Assets/image-30.jpeg';
import img31 from './Assets/image-31.jpeg';
import img32 from './Assets/image-32.jpeg';
import img33 from './Assets/image-33.jpeg';
import img34 from './Assets/image-34.jpeg';
import img35 from './Assets/image-35.jpeg';
import img36 from './Assets/image-36.jpeg';
import img37 from './Assets/image-37.jpeg';
import img38 from './Assets/image-38.jpeg';
import img39 from './Assets/image-39.jpeg';
import img40 from './Assets/image-40.jpeg';
import img41 from './Assets/image-41.jpeg';

function Product() {
  const [showPopup, setShowPopup] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [paymentDetails, setPaymentDetails] = useState({
    paymentMethod: '',
    name: '',
    address: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    email: '',
    phoneNumber: ''
  });

  const products = [
    { id: 1, name: "T-shirt", price: 150000, description: "Cotton T-shirt with graphic design.", image: (img) },
    { id: 2, name: "Jeans", price: 200000, description: "Denim jeans with a slim fit.", image: (img1) },
    { id: 3, name: "Jacket", price: 300000, description: "Warm winter jacket with hood.", image: (img2) },
    { id: 4, name: "Sneakers", price: 500000, description: "Comfortable sneakers for daily use.", image: (img3) },
    { id: 5, name: "Cap", price: 100000, description: "Classic baseball cap.", image: (img4)  },
    { id: 6, name: "Belt", price: 75000, description: "Leather belt with buckle.", image: (img5) },
    { id: 7, name: "Sweater", price: 250000, description: "Soft knitted sweater for colder days.", image: (img6) },
    { id: 8, name: "Shorts", price: 120000, description: "Casual shorts for everyday wear.", image: (img7) },
    { id: 9, name: "Boots", price: 450000, description: "Durable leather boots for outdoor use.", image: (img8) },
    { id: 10, name: "Sunglasses", price: 180000, description: "Stylish sunglasses with UV protection.", image: (img9) },
    { id: 11, name: "Watch", price: 350000, description: "Elegant wristwatch with metal band.", image: (img10) },
    { id: 12, name: "Scarf", price: 90000, description: "Warm wool scarf for winter.", image: (img11) },
    { id: 13, name: "Hoodie", price: 220000, description: "Cozy hoodie for casual wear.", image: (img12) },
    { id: 14, name: "Sweatpants", price: 180000, description: "Comfortable sweatpants for lounging.", image:(img13) },
    { id: 15, name: "Flip Flops", price: 50000, description: "Casual flip flops for beach days.", image: (img14) },
    { id: 16, name: "Raincoat", price: 280000, description: "Waterproof raincoat for rainy days.", image:(img15) },
    { id: 17, name: "Beanie", price: 60000, description: "Warm knitted beanie for winter.", image: (img16) },
    { id: 18, name: "Gloves", price: 90000, description: "Leather gloves for winter.", image: (img17) },
    { id: 19, name: "Polo Shirt", price: 170000, description: "Classic polo shirt for smart casual look.", image: (img18) },
    { id: 20, name: "Boots", price: 550000, description: "Stylish leather boots for formal and casual.", image:(img19) },
   
   
    { id: 22, name: "Sweater Vest", price: 230000, description: "Lightweight sweater vest for layering.", image: "https://d29c1z66frfv6c.cloudfront.net/pub/media/catalog/product/zoom/90550f2c878ef683cb57deea3d7468d354ce1559_xxl-1.jpg" },
    { id: 23, name: "Windbreaker", price: 270000, description: "Light jacket for breezy days.", image: "https://d29c1z66frfv6c.cloudfront.net/pub/media/catalog/product/zoom/273200413d3adc369a37910604a763fb2e2e11ea_xxl-1.jpg" },
    { id: 24, name: "Chinos", price: 220000, description: "Comfortable chinos for casual wear.", image: "https://communityclothing.co.uk/cdn/shop/files/Relaxed_ChinosKhaki_original_1_Portrait_6862ec57-0010-447f-aa2a-883e8f0171ad_2048x.jpg?v=1694641019" },
    { id: 25, name: "Rain Boots", price: 350000, description: "Water-resistant boots for wet weather.", image: "https://www.lonecone.com/cdn/shop/products/LC01-177_-Carousel-01.jpg?v=1603307531" },
    { id: 26, name: "Trench Coat", price: 450000, description: "Stylish trench coat for a smart look.", image: "https://assets.manufactum.de/p/068/068675/68675_01.jpg/ladies-trench-coat-etaproof.jpg?w=0&scale.option=fill&h=400&canvas.aspectratio=1%3A1&canvas.width=149.9750%25&canvas.height=100.0000%25" },
    { id: 27, name: "Backpack", price: 200000, description: "Spacious backpack for daily use.", image: "https://herschelsupplyco.co.uk/content/dam/herschel/products/11544/11544-05881-OS_01.jpg" },
    { id: 28, name: "sheTrmal Legging", price: 120000, description: "Thermal leggings for cold weather.", image: "https://dynamic.zacdn.com/Oko_9m4krjhdwgF9-u8kmU09FkE=/filters:quality(70):format(webp)/https://static-id.zacdn.com/p/penti-8970-1115834-1.jpg" },
    { id: 29, name: "Pullover", price: 210000, description: "Cozy pullover sweater for layering.", image: "https://dtcralphlauren.scene7.com/is/image/PoloGSI/s7-AI710909883005_alternate10?$rl_4x5_pdp$" },
    { id: 30, name: "Fleece Jacket", price: 280000, description: "Soft fleece jacket for outdoor adventures.", image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShuhKiUv-FCD1oTu03kfCm-dEEtMHuBj0eIQ&s" },
    { id: 31, name: "Canvas Shoes", price: 130000, description: "Casual canvas shoes for everyday wear.", image: "https://rukminim2.flixcart.com/image/850/1000/xif0q/shoe/q/b/g/6-na-224-labbin-black-original-imagzh4sm6tza6yk.jpeg?q=90&crop=false" },
    { id: 32, name: "Flannel Shirt", price: 160000, description: "Classic flannel shirt for a rugged look.", image: "https://i5.walmartimages.com/seo/Alimens-Gentle-Mens-Long-Sleeve-Red-Plaid-Flannel-Shirts-Casual-Button-Down-Regular-Fit_47368d7e-e823-49e8-94e1-b8013b3e5efb.7d2b07c1bea844052bc65903054e7ca8.jpeg" },
    { id: 33, name: "Yoga Pants", price: 110000, description: "Comfortable yoga pants for workouts.", image: "https://americantall.com/cdn/shop/products/American-Tall-Women-Balance-OpenBottom-Yoga-Pant-Black-side_1445x.jpg?v=1652450454" },
    { id: 34, name: "Denim Skirt", price: 130000, description: "Casual denim skirt for a laid-back style.", image: "https://d29c1z66frfv6c.cloudfront.net/pub/media/catalog/product/zoom/735f9559bcba0517b0c36f5a3ee86ca421247ed7_xxl-1.jpg" },
    
    
    { id: 35, name: "Bootcut Jeans", price: 220000, description: "Classic bootcut jeans for a timeless look.", image: (img20) },
    { id: 36, name: "Leather Jacket", price: 450000, description: "Sleek leather jacket for a cool look.", image: (img41) },
    { id: 37, name: "Cargos", price: 180000, description: "Practical cargo pants with multiple pockets.", image: (img40) },
    { id: 38, name: "Biker Shorts", price: 95000, description: "Comfortable biker shorts for casual wear.", image: (img39) },
    { id: 39, name: "Crewneck Sweatshirt", price: 190000, description: "Soft crewneck sweatshirt for a relaxed fit.", image: (img21) },
    { id: 40, name: "Knee-High Socks", price: 40000, description: "Comfortable knee-high socks for layering.", image: (img22) },
    { id: 41, name: "Messenger Bag", price: 270000, description: "Stylish messenger bag for carrying essentials.", image:(img23) },
    { id: 42, name: "Slippers", price: 80000, description: "Cozy slippers for indoor comfort.", image: (img30) },
    { id: 43, name: "Cardigan", price: 230000, description: "Lightweight cardigan for layering.", image: (img31) },
    { id: 44, name: "Winter Boots", price: 500000, description: "Insulated boots for snowy weather.", image: (img32) },
    { id: 45, name: "Windbreaker Jacket", price: 200000, description: "Lightweight jacket for breezy days.", image: (img33) },
    { id: 46, name: "Denim Jacket", price: 250000, description: "Classic denim jacket for casual looks.", image: (img34) },
    { id: 47, name: "Clutch Bag", price: 350000, description: "Elegant clutch bag for formal occasions.", image: (img35) },
    { id: 48, name: "Winter Hat", price: 55000, description: "Warm hat to protect from the cold.", image:  (img36) }
  ];
  

  const openPopup = (product) => {
    setSelectedProduct(product);
    setShowPopup(true);
  };

  const handlePaymentChange = (e) => {
    const { name, value } = e.target;
    setPaymentDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value
    }));
  };

  const handleBuyNow = () => {
    console.log(paymentDetails); 
    setShowPopup(false);
  };

 
  const validateEmail = (email) => {
    return email.includes('@');
  };

  const validatePhoneNumber = (phoneNumber) => {
    return /^[0-9]*$/.test(phoneNumber);
  };

  return (
    <div className="product-container">
      <h3 className="text-center mb-4">Our Products</h3>

      <div className="row mb-4">
        <h2 className="col-12">Category 1</h2>
        <div className="row row-cols-2 row-cols-sm-3 row-cols-md-4 g-4">
          {products.map((product) => (
            <div className="col" key={product.id}>
              <div className="card shadow-sm border-0">
                <img src={product.image} className="card-img-top" alt={product.name} />
                <div className="card-body text-center">
                  <h5 className="card-title">{product.name}</h5>
                  <h6 className="card-subtitle mb-2 text-muted">Rp {product.price.toLocaleString()}</h6>
                  <p className="card-text">{product.description}</p>
                  <button className="btn btn-primary" onClick={() => openPopup(product)}>
                    Buy Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>


      <Modal show={showPopup} onHide={() => setShowPopup(false)} centered>
        <Modal.Body>
          <h1 className="text-center">{selectedProduct?.name}</h1>
          <h5 className="text-center">Total Price: Rp {selectedProduct?.price}</h5>

          <div>
            <div className="mb-3">
              <label className="form-label">Payment Method</label>
              <select
                className="form-select"
                name="paymentMethod"
                value={paymentDetails.paymentMethod}
                onChange={handlePaymentChange}
                required
              >
                <option value="">Select Payment Method</option>
                <option value="paypal">PayPal</option>
                <option value="dana">DANA</option>
                <option value="ovo">OVO</option>
              </select>
            </div>

            {paymentDetails.paymentMethod && (
              <>
                {paymentDetails.paymentMethod === 'paypal' && (
                  <div className="mb-3">
                    <label className="form-label">PayPal Email</label>
                    <input
                      type="email"
                      className="form-control"
                      name="email"
                      value={paymentDetails.email || ''}
                      onChange={handlePaymentChange}
                      placeholder="Enter your PayPal email"
                      required
                    />
                  </div>
                )}

                {paymentDetails.paymentMethod === 'dana' && (
                  <>
                    <div className="mb-3">
                      <label className="form-label">Name DANA</label>
                      <input
                        type="text"
                        className="form-control"
                        name="name"
                        value={paymentDetails.name}
                        onChange={handlePaymentChange}
                        required
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Phone Number</label>
                      <input
                        type="number"
                        className="form-control"
                        name="phoneNumber"
                        value={paymentDetails.phoneNumber}
                        onChange={handlePaymentChange}
                        required
                        pattern="[0-9]*"
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Email</label>
                      <input
                        type="email"
                        className="form-control"
                        name="email"
                        value={paymentDetails.email || ''}
                        onChange={handlePaymentChange}
                        required
                        onBlur={(e) => {
                          if (!validateEmail(e.target.value)) {
                            alert("Email must contain '@'");
                          }
                        }}
                      />
                    </div>
                  </>
                )}

                {paymentDetails.paymentMethod === 'ovo' && (
                  <>
                    <div className="mb-3">
                      <label className="form-label">Name OVO</label>
                      <input
                        type="text"
                        className="form-control"
                        name="name"
                        value={paymentDetails.name}
                        onChange={handlePaymentChange}
                        required
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Phone Number</label>
                      <input
                        type="number"
                        className="form-control"
                        name="phoneNumber"
                        value={paymentDetails.phoneNumber}
                        onChange={handlePaymentChange}
                        required
                        pattern="[0-9]*" 
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Email</label>
                      <input
                        type="email"
                        className="form-control"
                        name="email"
                        value={paymentDetails.email || ''}
                        onChange={handlePaymentChange}
                        required
                        onBlur={(e) => {
                          if (!validateEmail(e.target.value)) {
                            alert("Email must contain '@'");
                          }
                        }}
                      />
                    </div>
                  </>
                )}
              </>
            )}
          </div>

          <div className="d-flex justify-content-center">
            <button className="btn btn-primary" onClick={handleBuyNow}>Proceed to Payment</button>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default Product;
