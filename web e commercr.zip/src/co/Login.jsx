import { useState } from 'react';
import './css/Login.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Login Failed');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      console.log("Login submitted", { username, password });
    }, 2000); 
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2>Login</h2>

        {error && <div className="alert alert-danger">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="input-group">
            <i className="fa fa-user"></i>
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>

          <div className="input-group">
            <i className="fa fa-eye" onClick={() => setShowPassword(!showPassword)} style={{ cursor: 'pointer' }}></i>
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button type="submit" className="login-btn" disabled={loading}>
            {loading ? <div className="loading-spinner"></div> : 'Login'}
          </button>
        </form>

        <div className="forgot-signup">
          <a href="/forgot">Forgot Password?</a>
          <span> Or </span>
          <a href="/sign">Sign Up</a>
        </div>
      </div>
    </div>
  );
}

export default Login;
