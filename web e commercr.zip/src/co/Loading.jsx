import React from 'react';
import './css/Loading.css';

function Loading() {
  return (
    <div className="loading-container">
      <span className="loading-text">Loading</span>
      <div className="loading-dots">
        <div className="dot"></div>
        <div className="dot"></div>
        <div className="dot"></div>
      </div>
    </div>
  );
}

export default Loading;
