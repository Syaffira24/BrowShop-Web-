import { useState, useRef } from 'react';
import { Container, Form, Button, InputGroup, FormControl, Spinner, Toast, Alert } from 'react-bootstrap';
import './css/Co.css';

function Contact() {
  const [formData, setFormData] = useState({
    username: '',
    recipient: '',
    vanityUrl: '',
    message: '',
    sendCopy: false,
    userEmail: '',
    phoneNumber: '',
    subject: '',
  });

  const [isValid, setIsValid] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [showToast, setShowToast] = useState(false);
  const [messageCount, setMessageCount] = useState(0);
  const [isConfirmed, setIsConfirmed] = useState(false);

  const messageInputRef = useRef();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });

    if (e.target.name === 'message') {
      setMessageCount(e.target.value.length);
    }
  };

  const handleSubjectChange = (e) => {
    setFormData({
      ...formData,
      subject: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.username && formData.recipient && formData.message && isConfirmed) {
      setIsValid(true);
      setIsSubmitting(true);

      setTimeout(() => {
        setIsSubmitting(false);
        setToastMessage('Message sent successfully!');
        setShowToast(true);
      }, 2000);
    } else {
      setIsValid(false);
      if (!formData.message) {
        messageInputRef.current.focus();
      }
    }
  };

  const handleReset = () => {
    setFormData({
      username: '',
      recipient: '',
      vanityUrl: '',
      message: '',
      sendCopy: false,
      userEmail: '',
      phoneNumber: '',
      subject: '',
    });
    setIsValid(true);
    setMessageCount(0);
  };

  const handleConfirmation = () => {
    setIsConfirmed(!isConfirmed);
  };

  return (
    <>
    <div className="pd">
 <Container className="form-container">
      <div className="form-wrapper">
        <Form onSubmit={handleSubmit}>
          <InputGroup className="mb-3">
            <FormControl
              type="text"
              placeholder="Username"
              name="username"
              value={formData.username}
              onChange={handleChange}
              aria-label="Username"
              isInvalid={!isValid && !formData.username}
            />
          </InputGroup>

          <InputGroup className="mb-3">
            <FormControl
              type="email"
              placeholder="Email"
              name="recipient"
              value={formData.recipient}
              onChange={handleChange}
              aria-label="Recipient's email"
              isInvalid={!isValid && !formData.recipient}
            />
          </InputGroup>
          <Form.Group className="mb-3">
            <Form.Label>Subject</Form.Label>
            <Form.Control
              as="select"
              name="subject"
              value={formData.subject}
              onChange={handleSubjectChange}
              isInvalid={!isValid && !formData.subject}
            >
              <option value="">Select a Subject</option>
              <option value="Feedback">Feedback</option>
              <option value="Inquiry">Inquiry</option>
              <option value="Support">Support</option>
            </Form.Control>
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Label>Message</Form.Label>
            <FormControl
              as="textarea"
              name="message"
              value={formData.message}
              onChange={handleChange}
              placeholder="Enter your message"
              rows={4}
              isInvalid={!isValid && !formData.message}
              ref={messageInputRef}
            />
            <Form.Text className="text-muted">{messageCount} / 500 characters</Form.Text>
            {messageCount > 450 && (
              <Alert variant="warning" className="mt-2">
                You're close to the character limit!
              </Alert>
            )}
          </Form.Group>

          <Form.Group className="mb-3">
            <Form.Check
              type="checkbox"
              label="I confirm to send this message"
              checked={isConfirmed}
              onChange={handleConfirmation}
            />
          </Form.Group>

          <div className="co button-container">
            <Button
              variant="primary"
              type="submit"
              disabled={isSubmitting || !isConfirmed}
            >
              {isSubmitting ? <Spinner animation="border" size="sm" /> : 'Send Message'}
            </Button>

            <Button variant="secondary" onClick={handleReset}>
              Reset Form
            </Button>
          </div>

          {!isValid && (
            <div className="mt-3 text-danger text-center">
              <small>Please fill out all required fields.</small>
            </div>
          )}
        </Form>
      </div>

      <Toast
        onClose={() => setShowToast(false)}
        show={showToast}
        delay={3000}
        autohide
        className="position-fixed"
      >
        <Toast.Body>{toastMessage}</Toast.Body>
      </Toast>
    </Container>
    </div>
    </>
    
   
  );
}

export default Contact;
