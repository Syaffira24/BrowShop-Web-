COLOR
#789DBC
#FFE3E3
#FEF9F2
#C9E9D2

{ id: 1, name: "T-shirt", price: 150000, description: "Cotton T-shirt with graphic design.", image: "![alt text](<WhatsApp Image 2024-11-01 at 20.30.19_25b30729.jpg>)" },
    { id: 2, name: "Jeans", price: 200000, description: "Denim jeans with a slim fit.", image: "![alt text](<WhatsApp Image 2024-11-01 at 20.30.19_25b30729-1.jpg>)" },
    { id: 3, name: "Jacket", price: 300000, description: "Warm winter jacket with hood.", image: "![alt text](<WhatsApp Image 2024-11-01 at 20.30.19_25b30729-2.jpg>)" },
    { id: 4, name: "Sneakers", price: 500000, description: "Comfortable sneakers for daily use.", image: "![alt text](image.png)" },
    { id: 5, name: "Cap", price: 100000, description: "Classic baseball cap.", image: "![alt text](image-1.png)" },
    { id: 6, name: "Belt", price: 75000, description: "Leather belt with buckle.", image: "![alt text](image-2.png)" },
    { id: 7, name: "Sweater", price: 250000, description: "Soft knitted sweater for colder days.", image: "![alt text](<WhatsApp Image 2024-11-01 at 20.30.19_25b30729-3.jpg>)" },
    { id: 8, name: "Shorts", price: 120000, description: "Casual shorts for everyday wear.", image: "![alt text](<WhatsApp Image 2024-11-02 at 10.51.22_b4218724.jpg>)" },
    { id: 9, name: "Boots", price: 450000, description: "Durable leather boots for outdoor use.", image: "![alt text](image-3.png)" },
    { id: 10, name: "Sunglasses", price: 180000, description: "Stylish sunglasses with UV protection.", image: "![alt text](image-4.png)" },
    { id: 11, name: "Watch", price: 350000, description: "Elegant wristwatch with metal band.", image: "![alt text](image-5.png)" },
    { id: 12, name: "Scarf", price: 90000, description: "Warm wool scarf for winter.", image: "![alt text](image-6.png)" },
    { id: 13, name: "Hoodie", price: 220000, description: "Cozy hoodie for casual wear.", image: "![alt text](<WhatsApp Image 2024-11-01 at 20.30.19_25b30729-4.jpg>)" },
    { id: 14, name: "Sweatpants", price: 180000, description: "Comfortable sweatpants for lounging.", image: "![alt text](<WhatsApp Image 2024-11-02 at 10.51.21_db365a54.jpg>)" },
    { id: 15, name: "Flip Flops", price: 50000, description: "Casual flip flops for beach days.", image: ![alt text](image-7.png)" },
    { id: 16, name: "Raincoat", price: 280000, description: "Waterproof raincoat for rainy days.", image: "![alt text](image-8.png)" },
    { id: 17, name: "Beanie", price: 60000, description: "Warm knitted beanie for winter.", image: "![alt text](image-9.png)" },
    { id: 18, name: "Gloves", price: 90000, description: "Leather gloves for winter.", image: "![alt text](image-10.png)" },
    { id: 19, name: "Polo Shirt", price: 170000, description: "Classic polo shirt for smart casual look.", image: "![alt text](image-11.png)" },
    { id: 20, name: "Boots", price: 550000, description: "Stylish leather boots for formal and casual.", image: "![alt text](image-12.png)" },
    { id: 21, name: "Bag", price: 320000, description: "Casual crossbody bag for everyday use.", image: ![alt text](image-13.png)" },
    { id: 22, name: "Sweater Vest", price: 230000, description: "Lightweight sweater vest for layering.", image: "![alt text](image-14.png)" },
    { id: 23, name: "Windbreaker", price: 270000, description: "Light jacket for breezy days.", image: "![alt text](image-15.png)" },
    { id: 24, name: "Chinos", price: 220000, description: "Comfortable chinos for casual wear.", image: "![alt text](<WhatsApp Image 2024-11-02 at 10.51.21_2557a171.jpg>)" },