import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'aos/dist/aos.css'; 
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { useEffect, useState } from 'react';

function Content() {
  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };

  return (
    <>
      <div
        className="container main-content d-flex flex-column flex-md-row align-items-center justify-content-center"
        style={{ minHeight: '100vh' }}
      >
        <div className="text-content col-12 col-md-6 mb-4 mb-md-0">
          <h1 className="text-dark text-center responsive-heading">
            Organ <span className="highlight">Shop</span>
          </h1>
          <p className="text-center text-white">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus at enim congue scelerisque sed, suscipit metus non iaculis semper.
          </p>
          <a
            className="btn btn-outline-primary text-white mt-3 custom-btn"
            href="/product"
           
          >
            LEARN MORE
          </a>
        </div>
      </div>
    </>
  );
}

export default Content;
