import React, { useState } from 'react';
import './style/styles.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Modal } from 'react-bootstrap';

function Product() {
  const [showPopup, setShowPopup] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [paymentDetails, setPaymentDetails] = useState({
    paymentMethod: '',
    name: '',
    address: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    email: '',
    phoneNumber: ''
  });

  const products = [
    { id: 1, name: "T-shirt", price: 150000, description: "Cotton T-shirt with graphic design.", image: "" },
    { id: 2, name: "Jeans", price: 200000, description: "Denim jeans with a slim fit.", image: "" },
    { id: 3, name: "Jacket", price: 300000, description: "Warm winter jacket with hood.", image: "" },
    { id: 4, name: "Sneakers", price: 500000, description: "Comfortable sneakers for daily use.", image: "" },
    { id: 5, name: "Cap", price: 100000, description: "Classic baseball cap.", image: "" },
    { id: 6, name: "Belt", price: 75000, description: "Leather belt with buckle.", image: "" },
    { id: 7, name: "Sweater", price: 250000, description: "Soft knitted sweater for colder days.", image: "" },
    { id: 8, name: "Shorts", price: 120000, description: "Casual shorts for everyday wear.", image: "" },
    { id: 9, name: "Boots", price: 450000, description: "Durable leather boots for outdoor use.", image: "" },
    { id: 10, name: "Sunglasses", price: 180000, description: "Stylish sunglasses with UV protection.", image: "" },
    { id: 11, name: "Watch", price: 350000, description: "Elegant wristwatch with metal band.", image: "" },
    { id: 12, name: "Scarf", price: 90000, description: "Warm wool scarf for winter.", image: "" },
    { id: 13, name: "Hoodie", price: 220000, description: "Cozy hoodie for casual wear.", image: "" },
    { id: 14, name: "Sweatpants", price: 180000, description: "Comfortable sweatpants for lounging.", image: "" },
    { id: 15, name: "Flip Flops", price: 50000, description: "Casual flip flops for beach days.", image: "" },
    { id: 16, name: "Raincoat", price: 280000, description: "Waterproof raincoat for rainy days.", image: "" },
    { id: 17, name: "Beanie", price: 60000, description: "Warm knitted beanie for winter.", image: "" },
    { id: 18, name: "Gloves", price: 90000, description: "Leather gloves for winter.", image: "" },
    { id: 19, name: "Polo Shirt", price: 170000, description: "Classic polo shirt for smart casual look.", image: "" },
    { id: 20, name: "Boots", price: 550000, description: "Stylish leather boots for formal and casual.", image: "" },
    { id: 21, name: "Bag", price: 320000, description: "Casual crossbody bag for everyday use.", image: "" },

    
    { id: 22, name: "Sweater Vest", price: 230000, description: "Lightweight sweater vest for layering.", image: "" },
    { id: 23, name: "Windbreaker", price: 270000, description: "Light jacket for breezy days.", image: "" },
    { id: 24, name: "Chinos", price: 220000, description: "Comfortable chinos for casual wear.", image: "" },
    { id: 25, name: "Rain Boots", price: 350000, description: "Water-resistant boots for wet weather.", image: "" },
    { id: 26, name: "Trench Coat", price: 450000, description: "Stylish trench coat for a smart look.", image: "" },
    { id: 27, name: "Backpack", price: 200000, description: "Spacious backpack for daily use.", image: "" },
    { id: 28, name: "Thermal Leggings", price: 120000, description: "Thermal leggings for cold weather.", image: "" },
    { id: 29, name: "Pullover", price: 210000, description: "Cozy pullover sweater for layering.", image: "" },
    { id: 30, name: "Fleece Jacket", price: 280000, description: "Soft fleece jacket for outdoor adventures.", image: "" },
    { id: 31, name: "Canvas Shoes", price: 130000, description: "Casual canvas shoes for everyday wear.", image: "" },
    { id: 32, name: "Flannel Shirt", price: 160000, description: "Classic flannel shirt for a rugged look.", image: "" },
    { id: 33, name: "Yoga Pants", price: 110000, description: "Comfortable yoga pants for workouts.", image: "" },
    { id: 34, name: "Denim Skirt", price: 130000, description: "Casual denim skirt for a laid-back style.", image: "" },
    { id: 35, name: "Bootcut Jeans", price: 220000, description: "Classic bootcut jeans for a timeless look.", image: "" },
    { id: 36, name: "Leather Jacket", price: 450000, description: "Sleek leather jacket for a cool look.", image: "" },
    { id: 37, name: "Cargos", price: 180000, description: "Practical cargo pants with multiple pockets.", image: "" },
    { id: 38, name: "Biker Shorts", price: 95000, description: "Comfortable biker shorts for casual wear.", image: "" },
    { id: 39, name: "Crewneck Sweatshirt", price: 190000, description: "Soft crewneck sweatshirt for a relaxed fit.", image: "" },
  
  
    { id: 40, name: "Knee-High Socks", price: 40000, description: "Comfortable knee-high socks for layering.", image: "" },
    { id: 41, name: "Messenger Bag", price: 270000, description: "Stylish messenger bag for carrying essentials.", image: "" },
    { id: 42, name: "Slippers", price: 80000, description: "Cozy slippers for indoor comfort.", image: "" },
    { id: 43, name: "Cardigan", price: 230000, description: "Lightweight cardigan for layering.", image: "" },
    { id: 44, name: "Winter Boots", price: 500000, description: "Insulated boots for snowy weather.", image: "" },
    { id: 45, name: "Windbreaker Jacket", price: 200000, description: "Lightweight jacket for breezy days.", image: "" },
    { id: 46, name: "Denim Jacket", price: 250000, description: "Classic denim jacket for casual looks.", image: "" },
    { id: 47, name: "Clutch Bag", price: 350000, description: "Elegant clutch bag for formal occasions.", image: "" },
    { id: 48, name: "Winter Hat", price: 55000, description: "Warm hat to protect from the cold.", image: "" },
  ];
  

  const openPopup = (product) => {
    setSelectedProduct(product);
    setShowPopup(true);
  };

  const handlePaymentChange = (e) => {
    const { name, value } = e.target;
    setPaymentDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value
    }));
  };

  const handleBuyNow = () => {
    console.log(paymentDetails); 
    setShowPopup(false);
  };

 
  const validateEmail = (email) => {
    return email.includes('@');
  };

  const validatePhoneNumber = (phoneNumber) => {
    return /^[0-9]*$/.test(phoneNumber);
  };

  return (
    <div className="product-container">
      <h3 className="text-center mb-4">Our Products</h3>

      <div className="row mb-4">
        <h2 className="col-12">Category 1</h2>
        <div className="row row-cols-2 row-cols-sm-3 row-cols-md-4 g-4">
          {products.map((product) => (
            <div className="col" key={product.id}>
              <div className="card shadow-sm border-0">
                <img src={product.image} className="card-img-top" alt={product.name} />
                <div className="card-body text-center">
                  <h5 className="card-title">{product.name}</h5>
                  <h6 className="card-subtitle mb-2 text-muted">Rp {product.price.toLocaleString()}</h6>
                  <p className="card-text">{product.description}</p>
                  <button className="btn btn-primary" onClick={() => openPopup(product)}>
                    Buy Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>


      <Modal show={showPopup} onHide={() => setShowPopup(false)} centered>
        <Modal.Body>
          <h1 className="text-center">{selectedProduct?.name}</h1>
          <h5 className="text-center">Total Price: Rp {selectedProduct?.price}</h5>

          <div>
            <div className="mb-3">
              <label className="form-label">Payment Method</label>
              <select
                className="form-select"
                name="paymentMethod"
                value={paymentDetails.paymentMethod}
                onChange={handlePaymentChange}
                required
              >
                <option value="">Select Payment Method</option>
                <option value="paypal">PayPal</option>
                <option value="dana">DANA</option>
                <option value="ovo">OVO</option>
              </select>
            </div>

            {paymentDetails.paymentMethod && (
              <>
                {paymentDetails.paymentMethod === 'paypal' && (
                  <div className="mb-3">
                    <label className="form-label">PayPal Email</label>
                    <input
                      type="email"
                      className="form-control"
                      name="email"
                      value={paymentDetails.email || ''}
                      onChange={handlePaymentChange}
                      placeholder="Enter your PayPal email"
                      required
                    />
                  </div>
                )}

                {paymentDetails.paymentMethod === 'dana' && (
                  <>
                    <div className="mb-3">
                      <label className="form-label">Name DANA</label>
                      <input
                        type="text"
                        className="form-control"
                        name="name"
                        value={paymentDetails.name}
                        onChange={handlePaymentChange}
                        required
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Phone Number</label>
                      <input
                        type="number"
                        className="form-control"
                        name="phoneNumber"
                        value={paymentDetails.phoneNumber}
                        onChange={handlePaymentChange}
                        required
                        pattern="[0-9]*"
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Email</label>
                      <input
                        type="email"
                        className="form-control"
                        name="email"
                        value={paymentDetails.email || ''}
                        onChange={handlePaymentChange}
                        required
                        onBlur={(e) => {
                          if (!validateEmail(e.target.value)) {
                            alert("Email must contain '@'");
                          }
                        }}
                      />
                    </div>
                  </>
                )}

                {paymentDetails.paymentMethod === 'ovo' && (
                  <>
                    <div className="mb-3">
                      <label className="form-label">Name OVO</label>
                      <input
                        type="text"
                        className="form-control"
                        name="name"
                        value={paymentDetails.name}
                        onChange={handlePaymentChange}
                        required
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Phone Number</label>
                      <input
                        type="number"
                        className="form-control"
                        name="phoneNumber"
                        value={paymentDetails.phoneNumber}
                        onChange={handlePaymentChange}
                        required
                        pattern="[0-9]*" 
                      />
                    </div>
                    <div className="mb-3">
                      <label className="form-label">Email</label>
                      <input
                        type="email"
                        className="form-control"
                        name="email"
                        value={paymentDetails.email || ''}
                        onChange={handlePaymentChange}
                        required
                        onBlur={(e) => {
                          if (!validateEmail(e.target.value)) {
                            alert("Email must contain '@'");
                          }
                        }}
                      />
                    </div>
                  </>
                )}
              </>
            )}
          </div>

          <div className="d-flex justify-content-center">
            <button className="btn btn-primary" onClick={handleBuyNow}>Proceed to Payment</button>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default Product;
