import '../App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from 'react';
import { Offcanvas } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';

function Nav({ onNavigate, scrollToSection }) {
  const [show, setShow] = useState(false);
  const navigate = useNavigate();

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleLinkClick = (path, section) => {
    handleClose();
    if (section) {
      scrollToSection(section); 
    } else {
      onNavigate(() => navigate(path)); 
    }
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg  fixed-top">
        <div className="container">
          <a className="navbar-brand" href="#">ORGAN <span>SHOP</span></a>
          <button 
            className="navbar-toggler" 
            type="button" 
            style={{border: 'none'}}
            aria-label="Toggle navigation" 
            onClick={handleShow}
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse justify-content-center">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link text-white" to="/" onClick={() => handleLinkClick('/', null)}>Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/product" onClick={() => handleLinkClick('/product', 'product')}>Product</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link text-white" to="/contact" onClick={() => handleLinkClick('/contact', 'contact')}>Contact</Link>
              </li>
              
            </ul>
            <ul className="navbar-nav ms-auto">
              <li className="nav-item">
                <Link to="/login" className="nav-link btn btn-primary text-white" onClick={() => handleLinkClick('/login', null)}>LOGIN</Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <Offcanvas show={show} onHide={handleClose} placement="end">
        <Offcanvas.Header closeButton>
          <Offcanvas.Title>Menu</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body>
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link to="/" className="nav-link text-dark" onClick={() => handleLinkClick('/', null)}>Home</Link>
            </li>
            <li className="nav-item">
              <Link to="#" className="nav-link text-dark" onClick={() => handleLinkClick('#', 'services')}>Services</Link>
            </li>
            <li className="nav-item">
              <Link to="#" className="nav-link text-dark" onClick={() => handleLinkClick('#', 'about')}>Pruduct</Link>
            </li>
            <li className="nav-item">
              <Link to="#" className="nav-link text-dark" onClick={() => handleLinkClick('#', 'contact')}>Contact</Link>
            </li>
            <li className="nav-item">
              <Link to="/login" className="nav-link btn btn-outline-primary" onClick={() => handleLinkClick('/login', null)}>LOGIN</Link>
            </li>
          </ul>
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
}

export default Nav;
