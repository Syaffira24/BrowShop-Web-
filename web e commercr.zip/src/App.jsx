import './App.css';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Content from './co/Content';
import Nav from './co/Nav';
import Login from './co/Login';
import Sign from './co/Sign';
import Forgot from './co/Forgot';
import Contact from './co/Contact';
import Product from './co/product/Product';
import Loading from './co/Loading';

function App() {
  const [loading, setLoading] = useState(true);


  useEffect(() => {
    const load = async () => {
      const delay = Math.random() * 2000 + 500 + 50 + 100; 
      await new Promise(resolve => setTimeout(resolve, delay));
      setLoading(false);
    };

    load();
  }, []); // Run once on component mount

  const handleNavigation = async (navigate) => {
    setLoading(true);
    const delay = Math.random() * 2000 + 500 + 50 + 100;
    await new Promise(resolve => setTimeout(resolve, delay));
    setLoading(false);
    navigate();
  };

  return (
    <>
        <Router>
          {loading ? (
              <Loading />
            ) : (
            <div>
            <Nav onNavigate={handleNavigation} /> 
              <Routes>
                <Route path="/" element={<Content />} />
                <Route path="/login" element={<Login />} />
                <Route path="/sign" element={<Sign />} />
                <Route path='/forgot' element={<Forgot/>}/>
                <Route path='/contact' element={<Contact/>}/>
                <Route path='/product' element={<Product/>}/>
              </Routes>
             </div>
              
        
        )}
        </Router>
  </>
  );
}

export default App;
